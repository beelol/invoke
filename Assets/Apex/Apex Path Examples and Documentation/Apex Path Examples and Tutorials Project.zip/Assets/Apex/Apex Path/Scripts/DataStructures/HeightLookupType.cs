﻿/* Copyright © 2014 Apex Software. All rights reserved. */
namespace Apex.DataStructures
{
    public enum HeightLookupType
    {
        Dictionary,

        QuadTree
    }
}
